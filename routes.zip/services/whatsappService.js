/**
 * WhatsApp Service — Sachiva / Wasend Integration
 *
 * For text/SMS: GET or POST with query/form params
 *   GET https://wasend.sachiva.cloud/api/send-message
 *     ?api_key={key}&number={recipient}&message={text}&type=sms
 * For documents: multipart/form-data POST with the actual PDF file
 *   POST https://wasend.sachiva.cloud/api/send-document
 *     api_key, number, message, file (binary), file_name, type
 *
 * FIX (this revision) — WhatsApp PDF invoice not sending:
 *   Logs showed the document-upload calls failing with a generic
 *   500 "Failed to send message", while the plain-text GET fallback
 *   failed with a proper 401 "Unauthorized" — using the SAME api_key.
 *   That mismatch is the tell: the GET call sends api_key as a URL
 *   query param (`?api_key=...`) and the server correctly validates
 *   it (and rejects it with 401 if wrong). The old multipart POST
 *   only sent api_key as a multipart form-data field — if Wasend's
 *   /api/send-document route reads api_key from the query string
 *   (like the GET route does) rather than from the form body, it
 *   never sees a key at all, so instead of a clean 401 it falls
 *   through to a generic "Failed to send message" 500.
 *
 *   Fix: the multipart POST now sends api_key/number/message/type/
 *   file_name BOTH as URL query params (like the working GET call)
 *   AND as form fields, so whichever one Wasend's server actually
 *   reads, it will find it. Also removed the old dead/broken
 *   `postForm` helper (it called requestGateway with a body argument
 *   that function never wrote to the socket, so it silently no-op'd),
 *   and trimmed the retry loop so failures are easier to read in logs.
 *
 *   NOTE: if you still get 401 Unauthorized after this fix, the
 *   `wasachiva_key` value itself is being rejected by Wasend/Sachiva —
 *   that's an account-side issue (invalid/expired key or WhatsApp
 *   session not linked), not something fixable from this file. Check
 *   the Sachiva/Wasend dashboard to confirm the key is active and the
 *   WhatsApp number is still connected (QR session not logged out).
 */

const https = require("https");
const http = require("http");
const fs = require("fs");
const path = require("path");
const { URL } = require("url");

const DEFAULT_BASE_URL =
  (process.env.wasachiva_url || process.env.WASACHIVA_URL || "https://wasend.sachiva.cloud")
    .replace(/\/+$/, "")
    .replace(/\?.*$/, "");

const API_KEY = process.env.wasachiva_key || process.env.WASACHIVA_KEY || "";

const normalizePhoneNumber = (raw) => {
  if (raw === null || raw === undefined) return null;
  let digits = String(raw).replace(/\D+/g, "");
  if (!digits) return null;
  if (digits.startsWith("00")) digits = digits.slice(2);
  if (digits.length === 10) digits = `91${digits}`;
  if (digits.length < 10 || digits.length > 15) return null;
  return digits;
};

const formatPhoneDisplay = (raw) => {
  const digits = normalizePhoneNumber(raw);
  if (!digits) return "N/A";
  if (digits.length >= 12) {
    const country = digits.slice(0, digits.length - 10);
    const local = digits.slice(-10);
    return `+${country} ${local.slice(0, 5)} ${local.slice(5)}`;
  }
  return digits;
};

// ── multipart/form-data helpers ──────────────────────────────────────────────
const rnd = () => Math.random().toString(36).slice(2, 10);

const buildMultipartBody = (fields, fileFieldName, fileBuffer, fileName) => {
  const boundary = `----WebKitFormBoundary${rnd()}`;
  const parts = [];

  for (const [key, value] of Object.entries(fields)) {
    parts.push(
      `--${boundary}\r\nContent-Disposition: form-data; name="${key}"\r\n\r\n${value}`
    );
  }

  if (fileBuffer) {
    const escapedFileName = fileName || "invoice.pdf";
    parts.push(
      `--${boundary}\r\nContent-Disposition: form-data; name="${fileFieldName}"; filename="${escapedFileName}"\r\nContent-Type: application/pdf\r\n\r\n`
    );
  }

  const preFile = Buffer.from(parts.join("\r\n"), "utf-8");
  let body;
  if (fileBuffer) {
    const postFile = Buffer.from(`\r\n--${boundary}--\r\n`, "utf-8");
    body = Buffer.concat([preFile, fileBuffer, postFile]);
  } else {
    body = Buffer.concat([preFile, Buffer.from(`\r\n--${boundary}--\r\n`, "utf-8")]);
  }

  return { boundary, body, contentType: `multipart/form-data; boundary=${boundary}` };
};

// ── Generic HTTP request (GET, no body) ──────────────────────────────────────
const requestGateway = (method, pathname, extraHeaders = {}) => {
  const baseUrl = new URL(DEFAULT_BASE_URL);
  const isHttps = baseUrl.protocol === "https:";
  const lib = isHttps ? https : http;

  return new Promise((resolve, reject) => {
    const req = lib.request(
      {
        method,
        hostname: baseUrl.hostname,
        port: baseUrl.port || (isHttps ? 443 : 80),
        path: pathname,
        headers: {
          Accept: "application/json",
          ...extraHeaders,
        },
        timeout: 60000,
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => { data += chunk; });
        res.on("end", () => {
          const trimmed = String(data || "").trim();
          let parsed = {};
          if (trimmed) {
            try { parsed = JSON.parse(trimmed); }
            catch { parsed = { raw: trimmed }; }
          }
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            const err = new Error(
              `Wasend responded ${res.statusCode}: ${JSON.stringify(parsed).slice(0, 300)}`,
            );
            err.statusCode = res.statusCode;
            err.body = parsed;
            console.error(`[Wasend Error] ${res.statusCode}:`, JSON.stringify(parsed));
            reject(err);
          }
        });
      },
    );
    req.on("timeout", () => req.destroy(new Error("Wasend request timed out")));
    req.on("error", reject);
    req.end();
  });
};

// ── GET (text / SMS) ──────────────────────────────────────────────────────────
const getFromGateway = (pathname, params = {}) => {
  const form = new URLSearchParams();
  form.set("api_key", params.api_key || API_KEY);
  if (params.number) form.set("number", params.number);
  if (params.message) form.set("message", params.message);
  if (params.file_url) form.set("file_url", params.file_url);
  if (params.type) form.set("type", params.type);
  if (params.file_name) form.set("file_name", params.file_name);
  const qs = form.toString();
  return requestGateway("GET", `${pathname}?${qs}`, { Accept: "application/json" });
};

// ── POST with multipart/form-data (document upload) ────────────────────────────
// FIX: api_key/number/message/type/file_name are now ALSO appended to the
// request URL as query params (mirroring the GET call that we know the
// server authenticates correctly), in addition to being sent as multipart
// form fields. Wasend's document endpoint may only read these from the
// query string, which is very likely why the old form-data-only version
// always failed with a generic 500 instead of a clean 401.
const postMultipart = async (pathname, fields, fileBuffer, fileName) => {
  const { body, contentType } = buildMultipartBody(fields, "file", fileBuffer, fileName);
  const baseUrl = new URL(DEFAULT_BASE_URL);
  const isHttps = baseUrl.protocol === "https:";
  const lib = isHttps ? https : http;

  const qs = new URLSearchParams();
  Object.entries(fields).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== "") qs.set(key, value);
  });
  const fullPath = `${pathname}?${qs.toString()}`;

  return new Promise((resolve, reject) => {
    const req = lib.request(
      {
        method: "POST",
        hostname: baseUrl.hostname,
        port: baseUrl.port || (isHttps ? 443 : 80),
        path: fullPath,
        headers: {
          Accept: "application/json",
          "Content-Type": contentType,
          "Content-Length": Buffer.byteLength(body),
        },
        timeout: 60000,
      },
      (res) => {
        let data = "";
        res.on("data", (chunk) => { data += chunk; });
        res.on("end", () => {
          const trimmed = String(data || "").trim();
          let parsed = {};
          if (trimmed) {
            try { parsed = JSON.parse(trimmed); }
            catch { parsed = { raw: trimmed }; }
          }
          if (res.statusCode >= 200 && res.statusCode < 300) {
            resolve(parsed);
          } else {
            const err = new Error(
              `Wasend responded ${res.statusCode}: ${JSON.stringify(parsed).slice(0, 300)}`,
            );
            err.statusCode = res.statusCode;
            err.body = parsed;
            console.error(`[Wasend multipart Error] ${res.statusCode}:`, JSON.stringify(parsed));
            reject(err);
          }
        });
      },
    );
    req.on("timeout", () => req.destroy(new Error("Wasend multipart request timed out")));
    req.on("error", reject);
    req.write(body);
    req.end();
  });
};

// ── Main: send document with file upload ──────────────────────────────────────
const sendWhatsAppMessage = async ({ number, message, filePath, fileName, type } = {}) => {
  const normalised = normalizePhoneNumber(number);
  if (!normalised) {
    return { ok: false, error: `Invalid phone number: ${number}`, number, channel: "whatsapp" };
  }
  if (!API_KEY) {
    return { ok: false, error: "wasachiva_key not configured", number: normalised, channel: "whatsapp" };
  }

  // ── 1. If we have a file path, try uploading the actual PDF ─────────────────
  // Per the documented API shape, the correct call is a single POST to
  // /api/send-document with api_key, number, message, file, file_name, type.
  // We try that exact shape first (now with query params too — see fix
  // note above), then a couple of narrow fallbacks in case the account's
  // Wasend instance expects a slightly different field name.
  if (filePath && fs.existsSync(filePath)) {
    const fileBuffer = fs.readFileSync(filePath);
    const fname = fileName || path.basename(filePath) || "invoice.pdf";

    const attempts = [
      { endpoint: "/api/send-document", fields: { type: "document", file_name: fname } },
      { endpoint: "/api/send-document", fields: { type: "document", filename: fname } },
      { endpoint: "/api/send-message", fields: { type: "document", file_name: fname } },
    ];

    for (const { endpoint, fields } of attempts) {
      try {
        const response = await postMultipart(endpoint, {
          api_key: API_KEY,
          number: normalised,
          message: message || "",
          ...fields,
        }, fileBuffer, fname);

        if (response?.status !== "error") {
          return { ok: true, statusCode: 200, response, number: normalised, channel: "whatsapp" };
        }
        console.error(`[WhatsApp] multipart ${endpoint} fields=${JSON.stringify(fields)}: ${JSON.stringify(response)}`);
      } catch (err) {
        console.error(`[WhatsApp] multipart ${endpoint} fields=${JSON.stringify(fields)} failed: ${err.message}`);
      }
    }
  }

  // ── 2. Fallback: try with file_url (if we don't have the file or upload failed) ─
  const msg = message || "";
  const shapes = [
    { api_key: API_KEY, number: normalised, message: msg, type: "document" },
    { api_key: API_KEY, number: normalised, message: msg },
  ];

  let lastErr = null;
  for (const params of shapes) {
    try {
      const response = await getFromGateway("/api/send-message", params);
      if (response?.status !== "error") {
        return { ok: true, statusCode: 200, response, number: normalised, channel: "whatsapp" };
      }
      const rawCode = response.code || response.statusCode || 0;
      lastErr = new Error(response.error || response.message || `Wasend error (code: ${rawCode})`);
      lastErr.statusCode = typeof rawCode === "number" ? rawCode : Number(rawCode) || 400;
      lastErr.body = response;
      console.error(`[WhatsApp] GET shape failed: ${lastErr.message}`);
    } catch (err) {
      lastErr = err;
      console.error(`[WhatsApp] GET shape failed: ${err.message}`);
    }
  }

  // ── 3. Text-only fallback: send the message without document ──────────────
  try {
    const textMsg = filePath
      ? `${msg}\n\nYour invoice PDF is available. Please contact the resort for a copy.`
      : msg;
    const textResponse = await getFromGateway("/api/send-message", {
      api_key: API_KEY,
      number: normalised,
      message: textMsg,
    });
    return {
      ok: true,
      statusCode: 200,
      response: textResponse,
      number: normalised,
      channel: "whatsapp",
      fallback: true,
      fallbackReason: lastErr?.message || "document upload not supported",
    };
  } catch (textErr) {
    return {
      ok: false,
      statusCode: lastErr?.statusCode || 0,
      error: `Document send failed: ${lastErr?.message || "unknown"}. Text fallback also failed: ${textErr.message}`,
      body: lastErr?.body,
      number: normalised,
      channel: "whatsapp",
    };
  }
};

// ── SMS ───────────────────────────────────────────────────────────────────────
const sendSmsMessage = async ({ number, message } = {}) => {
  const normalised = normalizePhoneNumber(number);
  if (!normalised) {
    return { ok: false, error: "Invalid phone number", number, channel: "sms" };
  }
  if (!API_KEY) {
    return { ok: false, error: "wasachiva_key not configured", number: normalised, channel: "sms" };
  }

  try {
    const response = await getFromGateway("/api/send-message", {
      api_key: API_KEY,
      number: normalised,
      message: message || "",
      type: "sms",
    });
    if (response?.status === "error") {
      const err = new Error(response.error || "Wasend reported an error");
      err.statusCode = response.code || 400;
      err.body = response;
      throw err;
    }
    return { ok: true, statusCode: 200, response, number: normalised, channel: "sms" };
  } catch (err) {
    return {
      ok: false,
      statusCode: err.statusCode || 0,
      error: err.message,
      number: normalised,
      channel: "sms",
    };
  }
};

// ── Invoice notifications ─────────────────────────────────────────────────────
const sendInvoiceNotifications = async (invoice, attachment, options = {}) => {
  const customerNumber = options.customerNumber || invoice.phone || "";
  const adminNumber = options.adminNumber || "";
  const guestName = invoice.customerName || "Valued Guest";
  const total = `₹ ${(invoice.totalAmount || 0).toFixed(2)}`;
  const invoiceNo = invoice.invoiceNo || `#${invoice.bookingId || invoice.customerId || ""}`;

  const customerMessage =
    options.customerMessage ||
    `Dear ${guestName},\n\nThank you for staying at Maa Baglamukhi Resort.\n\nHere is your invoice ${invoiceNo}.\nTotal: ${total}\n\nPlease find the invoice attached.\n\nRegards,\nMaa Baglamukhi Resort`;

  const adminMessage =
    options.adminMessage ||
    `New invoice generated for booking ${invoiceNo}.\nGuest: ${guestName}\nPhone: ${formatPhoneDisplay(customerNumber)}\nTotal: ${total}\nStatus: ${invoice.paymentStatus || "Pending"}`;

  let customerWa = { skipped: true, reason: "No customer phone number" };
  if (customerNumber) {
    customerWa = await sendWhatsAppMessage({
      number: customerNumber,
      message: customerMessage,
      filePath: attachment?.filePath,
      fileName: attachment?.fileName,
    });
  }

  let customerSms = { skipped: true, reason: "No customer phone number" };
  if (customerNumber) {
    customerSms = await sendSmsMessage({ number: customerNumber, message: customerMessage });
  }

  let adminWa = { skipped: true, reason: "Admin number not configured" };
  if (adminNumber) {
    adminWa = await sendWhatsAppMessage({
      number: adminNumber,
      message: adminMessage,
      filePath: attachment?.filePath,
      fileName: attachment?.fileName,
    });
  }

  let adminSms = { skipped: true, reason: "Admin number not configured" };
  if (adminNumber) {
    adminSms = await sendSmsMessage({ number: adminNumber, message: adminMessage });
  }

  return {
    customer: { whatsapp: customerWa, sms: customerSms },
    admin: { whatsapp: adminWa, sms: adminSms },
  };
};

module.exports = {
  normalizePhoneNumber,
  formatPhoneDisplay,
  sendWhatsAppMessage,
  sendSmsMessage,
  sendInvoiceNotifications,
};